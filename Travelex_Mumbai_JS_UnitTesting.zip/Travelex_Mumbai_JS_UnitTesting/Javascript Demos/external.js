function AddCourses(){
    var inputValue  = document.getElementById('targetTxt').value;
    var newLi = document.createElement("li");
    newLi.innerHTML = inputValue;
   var theList = document.querySelector('#list');
   theList.appendChild(newLi); // adds to the DOM !
}
