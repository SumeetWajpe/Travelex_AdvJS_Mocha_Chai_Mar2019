var app = require('./app'); // import the source file !
var chai = require('chai'); // 3rd Party module 
var expect = chai.expect;
var sinon = require('sinon');

describe('test app file',()=>{
    context('test functions in node',()=>{
        it('should add two numbers',()=>{
            let result = app.Add(10,20);
            expect(result).to.equal(30);
        });  
    });

    context('test async code',()=>{
        it('should test add callback',(done)=>{
            app.AddCallBack(10,20,(err,result)=>{
                expect(err).to.not.exist;
                expect(result).to.equal(30);
                done();
            });
        });
    });

    context('test async code',()=>{
        it('should test promise callback',(done)=>{
          app.AddPromise(10,20)
          .then(
              (result)=>{
                    expect(result).to.equal(30);
                    done();
          })
          .catch(
              (err)=>{                   
                    done(err);
              }
          )          
        });
   });

   context('test spy code',()=>{
    it('should spy on console',()=>{
        let spy = sinon.spy(console,'log')
        app.InvokeConsoleMethods();
        expect(spy.calledOnce).to.be.true;       
        spy.restore();
        });
    });
    context('test stub code',()=>{
        it('should stub on console.warn',()=>{
            let stub = sinon.stub(console,'warn');
            // let stub = sinon.stub(console,'warn').callsFake(()=>console.log('Fake Method Body !'))

            app.InvokeConsoleMethods();
            expect(stub.calledOnce).to.be.true;
            stub.restore();
            });
        });
});

