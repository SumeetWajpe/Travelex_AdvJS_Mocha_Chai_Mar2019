module.exports.Add = function (x,y){
    return x + y;
}


module.exports.AddCallBack = function(x,y,callback){
    setTimeout(()=>{
        return callback(null,x + y)
    },500);
}

module.exports.AddPromise = function(x,y){
    // return Promise.reject(new Error('explicit error'));
    return Promise.resolve(x+y);
}


module.exports.InvokeConsoleMethods = function(){
    console.log('console.log called !');
    console.warn('console.warn called !');

}
