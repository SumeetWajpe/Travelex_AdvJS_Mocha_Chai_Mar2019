var request = require('request'); // makes an ajax request !
var chai = require('chai'); // 3rd Party module 
// var expect = chai.expect;
var should = chai.should();
var sinon = require('sinon');
var posts = require('./fixtures/posts.json');


describe('suites for http calls',()=>{
    context('context for http calls without stub',()=>{
        it('should return all posts',(done)=>{
                request.get('https://jsonplaceholder.typicode.com/posts',(err,response,body)=>{
                    // there should be 200 as status code !
                    response.statusCode.should.eql(200);
                    // length should be 100
                    body = JSON.parse(body);
                    body.length.should.eql(100);
                    // first title should be 'sunt aut facere repellat provident occaecati excepturi optio reprehenderit'
                     body[0].title.should.eql('sunt aut facere repellat provident occaecati excepturi optio reprehenderit')
                 });// eof get
                done();
        });// eof it
    });// eof context
    describe('http calls when  stubbed',()=>{
        beforeEach(()=>{
            this.get = sinon.stub(request,'get');
        });
        afterEach(()=>{
            request.get.restore();
        });

        it('should return all posts when stubbed',(done)=>{

            // return the fixture data
            this.get.yields(null,posts.res,JSON.stringify(posts.body)); // stubbing

            request.get('https://jsonplaceholder.typicode.com/posts',(err,response,body)=>{
                // there should be 200 as status code !
                response.statusCode.should.eql(200);
                //length should be 100
                console.log(body);
                body = JSON.parse(body);
                body.length.should.eql(100);
                // first title should be 'sunt aut facere repellat provident occaecati excepturi optio reprehenderit'
                 body[0].title.should.eql('sunt aut facere repellat provident occaecati excepturi optio reprehenderit')
             });// eof get
            done();
    });// eof it


    })
})
