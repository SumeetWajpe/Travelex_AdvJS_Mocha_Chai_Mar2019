var assert = require('assert');



describe('webdriver website', () => {
    it('should do some node assertions', () => {
        browser.url('https://webdriver.io');
        var title = browser.getTitle();        
        assert.equal(title,"WebdriverIO · Next-gen WebDriver test framework for Node.js")
        browser.pause(30000);
    });
});