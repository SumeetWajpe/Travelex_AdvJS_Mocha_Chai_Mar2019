var chai = require('chai');
var expect = chai.expect;


describe("test suite to be tested using mocha",()=>{
    context("context ecapsulates many tests",()=>{
        it('test using chai api',()=>{
            // assertions using chai !
            expect(10).to.equal(10);
        });

        it('test deep Equal',()=>{
            // assertions using chai !
            // expect({name:'Travelex'}).to.deep.equal({name:'Travelex'})
            // expect({name:'Travelex'}).to.have.property('name').to.equal('Travelex');
            // expect({name:'Travelex'}).to.be.a('object');
            // expect('Travelex').to.be.a('string');
            // expect(5 > 8).to.be.false;
            // expect(undefined).to.not.exist;
            //  expect(1).to.exist;
            expect(null).to.be.null;

        })
    })
})
 