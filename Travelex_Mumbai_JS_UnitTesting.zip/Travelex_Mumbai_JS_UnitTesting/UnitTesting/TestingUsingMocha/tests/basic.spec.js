var assert = require('assert');


   
// before(()=>{
//     console.log("=======> Within Before Global")
// })

describe("test suite to be tested using mocha",()=>{
        context("context ecapsulates many tests",()=>{
            
            before(()=>{
                console.log("=======> Within Before")
            })
            beforeEach(()=>{
                console.log("=======> Within beforeEach")
            })
            
            it("tests first test case",()=>{
                        assert.equal(10,10); // node assert library ! 
                    })

            it("tests deepEqual test case",()=>{
                            assert.deepEqual({name:'ABC'},{name:'ABC'}) 
                        })
                        after(()=>{
                             console.log("=======> Within after")
                        })
                        afterEach(()=>{
                            console.log("=======> Within afterEach")

                       })

                       it("test pending");
            })
})  

