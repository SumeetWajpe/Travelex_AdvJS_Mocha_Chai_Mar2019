function GetData(){ 
  return  new Promise(function(resolve,reject){
 // make ajax request
 var xmlHttpObj = new XMLHttpRequest();
 xmlHttpObj.open("GET","https://jsonplaceholder.typicode.com/posts")
 xmlHttpObj.send();
 xmlHttpObj.onreadystatechange = function(){
     if(xmlHttpObj.readyState == 4 && xmlHttpObj.status == 200){
         resolve(xmlHttpObj.responseText)
     }else if(xmlHttpObj.readyState == 4 && xmlHttpObj.status !== 200){
        reject('Error '  + xmlHttpObj.status);
         }// eof else if
        }// eof onreadystatechange
    })// eof Promise()
}// eof getData()